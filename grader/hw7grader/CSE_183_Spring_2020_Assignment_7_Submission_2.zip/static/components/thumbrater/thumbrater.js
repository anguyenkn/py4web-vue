(function(){

    // Based off of Professor's StarRater

    var thumbrater = {
        props: ['url', 'callback_url'],
        data: null,
        methods: {}
    };

    thumbrater.data = function() {
        var data = {
            thumbs_rating: 0,
            get_url: this.url,
            set_url: this.callback_url,
        };
        thumbrater.methods.load.call(data);
        return data;
    };

    thumbrater.methods.set_rating = function (rating) {
        // Sets and sends to the server the thumbs.
        let self = this;
        // rating: 1 = thumbs up, -1 = thumbs down
        if (rating === 1) {
            // If image has no rating, thumbs up
            // If image already has thumbs up, reset rating
            if (self.thumbs_rating === 1) {rating = 0;}
            else {rating = 1;}
        }
        else {
            // If image has no rating, thumbs down
            // If image already has thumbs down, reset rating
            if (self.thumbs_rating === -1) {rating = 0;}
            else {rating = -1;}
        }
        self.thumbs_rating = rating;
        axios.get(self.set_url,
            {params: {rating: self.thumbs_rating}});
    };

    thumbrater.methods.load = function () {
        // In use, self will correspond to the data of the table,
        // as this is called via grid.methods.load
        let self = this;
        axios.get(self.get_url)
            .then(function(res) {
                self.thumbs_rating = res.data.rating;
            })
    };

    utils.register_vue_component('thumbrater', 'components/thumbrater/thumbrater.html',
        function(template) {
            thumbrater.template = template.data;
            return thumbrater;
        });
})();
