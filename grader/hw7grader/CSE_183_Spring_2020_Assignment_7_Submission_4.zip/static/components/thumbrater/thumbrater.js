(function(){

    // TODO: Complete.
    var thumbrater = {
        props: ['url', 'callback_url'],
        data: null,
        methods: {}
    };

    thumbrater.data = function() {
        var data = {
			thumb_status: 0,
            get_url: this.url,
            set_url: this.callback_url,
        };
        thumbrater.methods.load.call(data);
        return data;
    };
/**
    starrater.methods.stars_over = function (star_idx) {
        // When hovering over a star, we display that many stars.
        console.log("Over:", star_idx);
        let self = this;
        self.num_stars_display = star_idx;
    };

    starrater.methods.stars_out = function () {
        // Sets the number of stars back to the number of true stars.
        let self = this;
        self.num_stars_display = self.num_stars_assigned;
    };
*/
    thumbrater.methods.set_rating = function (thumb) {
        // Sets and sends to the server the number of stars.
        let self = this;
        if(thumb==1){
			if(self.thumb_status==1){
				self.thumb_status = 0;
			}else{
				self.thumb_status = 1;
			}
		}else if (thumb==2){
			if(self.thumb_status==2){
				self.thumb_status = 0;
			}else{
				self.thumb_status = 2;
			}
		}
        axios.get(self.set_url,
            {params: {rating: self.thumb_status}});
    };

    thumbrater.methods.load = function () {
        // In use, self will correspond to the data of the table,
        // as this is called via grid.methods.load
        let self = this;
        axios.get(self.get_url)
            .then(function(res) {
                self.thumb_status = res.data.rating;
            })
    };

    utils.register_vue_component('thumbrater', 'components/thumbrater/thumbrater.html',
        function(template) {
            thumbrater.template = template.data;
            return thumbrater;
        });
})();
