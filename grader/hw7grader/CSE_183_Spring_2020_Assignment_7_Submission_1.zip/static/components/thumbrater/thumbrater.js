(function(){

    // TODO: Complete.
    var thumbrater = {
        props: ['url', 'callback_url'],
        data: null,
        methods: {}
    };

    thumbrater.data = function () {
        var data = {
            rating: null,
            get_url: this.url,
            set_url: this.callback_url,
        };
        thumbrater.methods.load.call(data);
        return data;
    };

    thumbrater.methods.set_rating = function (new_rating) {
        // Sets and sends to the server the number of stars.
        let self = this;
        self.rating = new_rating;
        axios.get(self.set_url,
            {params: {rating: self.rating}});
    };

    thumbrater.methods.load = function () {
        // In use, self will correspond to the data of the table,
        // as this is called via grid.methods.load
        let self = this;
        axios.get(self.get_url)
            .then(function(res) {
                self.rating = res.data.rating;
                if (self.rating == null) {
                    self.rating = 0;
                }
            })
    };

    utils.register_vue_component('thumbrater', 'components/thumbrater/thumbrater.html',
        function(template) {
            thumbrater.template = template.data;
            return thumbrater;
        });


})();
